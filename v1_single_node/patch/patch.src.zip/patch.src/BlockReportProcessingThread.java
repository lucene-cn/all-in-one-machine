package org.apache.hadoop.hdfs.server.namenode;

import java.util.concurrent.LinkedBlockingQueue;

import org.apache.hadoop.util.ExitUtil;
import org.apache.hadoop.util.Time;

public class BlockReportProcessingThread extends Thread {
	private static final long MAX_LOCK_HOLD_MS = 100;

	private final LinkedBlockingQueue<Runnable> queue;
	protected final FSNamesystem namesystem;

	public BlockReportProcessingThread(FSNamesystem namesystem, LinkedBlockingQueue<Runnable> queue) {
		super("Block report processor");

		this.namesystem = namesystem;
		this.queue =queue;
		setDaemon(true);
	}

	@Override
	public void run() {
		try {
			processQueue();
		} catch (Throwable t) {
			ExitUtil.terminate(1, getName() + " encountered fatal exception: " + t);
		}
	}

	private void processQueue() {
		
		while (namesystem.isRunning()) {
			try {
				Runnable action = queue.take();
				namesystem.writeLock();
				try {
					long start = Time.monotonicNow();
					do {
						action.run();
						if (Time.monotonicNow() - start > MAX_LOCK_HOLD_MS) {
							break;
						}
						action = queue.poll();
					} while (action != null);
				} finally {
					namesystem.writeUnlock();
				}
				
			} catch (InterruptedException e) {
				if (Thread.interrupted()) {
					break;
				}
			}
		}
		queue.clear();
	}

}
